#!/bin/sh
# M-Vave-OP1 installer: serves this folder on http://localhost:8000 and opens it (Chrome or Edge). Close this window to stop.
cd "$(dirname "$0")"
(sleep 1; open -a "Google Chrome" "http://localhost:8000/webapp/installer/" 2>/dev/null || open "http://localhost:8000/webapp/installer/") &
python3 -m http.server 8000
