#!/bin/sh
# M-Vave-OP1 installer: serves this folder and opens it (Chrome or Edge). Close this window to stop.
cd "$(dirname "$0")"
python3 serve.py
