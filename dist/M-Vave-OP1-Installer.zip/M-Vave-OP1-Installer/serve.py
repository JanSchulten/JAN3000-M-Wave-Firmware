# M-Vave-OP1 installer: serves this folder on a free port of this computer and opens the installer in Chrome / Edge
import http.server, os, subprocess, sys, webbrowser
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
url = "http://127.0.0.1:%d/webapp/installer/" % srv.server_address[1]
print("M-Vave-OP1 installer:", url, "(close this window to stop)")
fw = [f for f in os.listdir("firmware") if f.startswith("felucca-") and f.endswith(".fwsc")]
print("firmware:", ", ".join(fw))
if sys.platform == "darwin":
    if subprocess.call(["open", "-a", "Google Chrome", url]) != 0:
        subprocess.call(["open", url])
else:
    webbrowser.open(url)
srv.serve_forever()
