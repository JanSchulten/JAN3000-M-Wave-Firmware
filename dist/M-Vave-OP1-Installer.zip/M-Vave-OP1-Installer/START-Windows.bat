@echo off
rem M-Vave-OP1 installer: serves this folder and opens it (Chrome or Edge). Close this window to stop.
cd /d "%~dp0"
py -3 serve.py || python serve.py
pause
