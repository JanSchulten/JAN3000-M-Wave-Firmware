@echo off
rem M-Vave-OP1 installer: serves this folder on http://localhost:8000 and opens it (Chrome or Edge). Close this window to stop.
cd /d "%~dp0"
start "" "http://localhost:8000/webapp/installer/"
py -3 -m http.server 8000 || python -m http.server 8000
pause
